package login;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey
    public String username;
    @ColumnInfo(name = "birthday")
    public String birthday;
    @ColumnInfo(name = "password")
    public String password;
    @ColumnInfo(name = "clientName")
    public String clientName;
    @ColumnInfo(name = "gender")
    public String gender;
    @ColumnInfo(name = "isAdmin")
    public boolean isAdmin;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean admin) {
        isAdmin = false;
    }

    /*
    public User(String clientName, String birthday, String username, String password, String gender, boolean isAdmin) {
        this.clientName = clientName;
        this.birthday = birthday;
        this.username = username;
        this.password = password;
        this.gender = gender;
        this.isAdmin = false;
    }*/
}